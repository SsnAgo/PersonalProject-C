## 项目：

一个能统计文件的字符数 单词总数 有效行数 单词的出现次数的程序 

运行：将.cpp和.h文件一起在vs2017里打开 然后再命令行提示窗口输入读取的文本和输出的文本 ，从input里读取文章输出到呕output.txt里

功能简介 1 统计一篇文章的字符数      

​                 2 统计文章的单词总数 

​                 3 统计文章的有效行数

​                 4将出现次数前十的单词注意输出到output.txt上

作业链接：[项目地址](https://github.com/llk1233/PersonalProject-C)

博客链接:[博客地址](https://www.cnblogs.com/liaolongkai/p/14456525.html)

