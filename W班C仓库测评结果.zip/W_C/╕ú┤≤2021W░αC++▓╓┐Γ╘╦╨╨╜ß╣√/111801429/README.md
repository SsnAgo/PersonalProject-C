# 命令行程序WordCount

## 运行
```
python WordCount.py input.txt output.txt
```

***

## 功能简介
    统计文件中的字符数、单词数、有效行数、词频前十的单词及其词频

***

## 作业链接
[软工实践寒假作业（2/2）](https://www.cnblogs.com/lilith0120/p/14426508.html)

***

## 博客链接
[天问的九歌's blog](https://www.cnblogs.com/lilith0120/)