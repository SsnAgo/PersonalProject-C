## 项目描述

统计文件中字符数、行数、单词数，并输出频率前十的单词。


## 作业链接

[寒假作业(2/2)](https://edu.cnblogs.com/campus/fzu/FZUSESPR21/homework/11672)

## 博客链接

[个人博客](https://www.cnblogs.com/smsbQAQ/p/14488805.html)