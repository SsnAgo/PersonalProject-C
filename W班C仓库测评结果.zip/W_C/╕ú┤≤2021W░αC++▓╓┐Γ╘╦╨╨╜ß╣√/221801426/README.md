## 项目：WordCount
### 功能简介
>  统计文件的字符数

>  统计文件的单词数

>  统计文件的有效行数

>  输出文件中最频繁的10个单词
### 如何运行
> 在命令行窗口(cmd)中输入：WordCount.exe input.txt output.txt
## 作业连接
  [软工实践寒假作业（2/2）](https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740)
  
## 博客链接
  [博客链接](https://www.cnblogs.com/Linzkk/p/14455324.html)
  
