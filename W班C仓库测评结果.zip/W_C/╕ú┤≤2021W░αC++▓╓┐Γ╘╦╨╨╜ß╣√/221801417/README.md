#如何运行
读取input.txt文件，统计字符数，行数，单词数，词频最高的10个单词，输出到output.txt中
#功能简介
统计目标文件的字符数，行数，有效单词数，并输出词频最高的10个单词
#作业链接
https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740
#博客链接
https://www.cnblogs.com/amicus/p/14458987.html