#pragma once
#include "pch.h"
#include<iostream>
#include<stdio.h>
#include<stdlib.h>
#include<algorithm>
#include<fstream>
#include<string>
#include<map>
#include<vector>
#include<regex>
using namespace std;

void wordFre(char * filename);